
import './App.css'
import Footer from './Components/Footer'
import Nav from './Components/Nav'
import About from './Pages/About'
import Contact from './Pages/Contact'
import Index from './Pages/Index'
import {
  RouterProvider,
} from "react-router-dom";

<BrowserRouter>
      <Routes>
        <Route path='/Home' Component={<Index/>} />
        <Route path='/About' Component={<About/>} />
        <Route path='/Contact' Component={<Contact/>} />

      </Routes>
    </BrowserRouter>
function App() {


  return (
    <><RouterProvider router={router} /><>
      <Nav />
      <Index />
      <About />
      <Contact />
      <Footer />

    </></>
    
  )
}

export default App

